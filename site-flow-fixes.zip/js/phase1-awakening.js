/**
 * Phase 1: Awakening — Ya Heard Me Audiobook Journey
 * Correct structure: Introduction + 9 Chapters + Conclusion = 11 sections
 * Audio: Firebase Storage → Google Drive fallback
 * Progress: Firestore users/{uid}/journey_progress/current
 */

(function () {
    'use strict';

    // ─── CHAPTER DATA (matches Ya Heard Me book exactly) ─────────────
    var TOTAL_SECTIONS = 11;

    // Google Drive fallback IDs
    var DRIVE_IDS = {
        intro:      '1hwRwWKa7TcP6iXLP4fia7A9Hg7CN8vSS',
        ch1:        '1xjGZAE9e_B7FGMqtW-ujp7gCT5pEk9wc',
        ch2:        '1qxlYoLaYI_8iyOWkP7NrS2XOphrtKFOX',
        ch3:        '1PrIRPymEsnlMx9G7vL0htbpSsM8MN0_s',
        ch4:        '1fNWY8-cyWLPOmmy5QmQGrMu6aXRiF5wC',
        ch5:        '1dqTo_AgYH6Rtvmii5L2EonHe7dXYDV74',
        ch6:        '172xFi6l6U0cXerrjQPvK7tou3_WdPSpb',
        ch7:        '1N6xlY7UAjuU3i3pCdX0-uCXUFuXzlRYr',
        ch8:        '1q7bJgZkNXRutSu-PrKSERQBlkR8aLF0x',
        ch9:        '1mS-shUXhHfiP9cdI_spbDny8LXLg64XN',
        conclusion: '1UO1IuinGpvsp3uYZqJmE-a8p9nl5dyfM'
    };

    // Firebase Storage path patterns to try (in order of priority)
    // We try multiple naming conventions since we don't know the exact upload names
    function getStoragePathCandidates(sectionId) {
        var names = {
            intro:      ['introduction', 'intro', 'Introduction', 'Intro', '00-introduction', '00-intro'],
            ch1:        ['chapter-1', 'chapter-01', 'Chapter-1', 'Chapter 1', 'ch1', '01-chapter-1'],
            ch2:        ['chapter-2', 'chapter-02', 'Chapter-2', 'Chapter 2', 'ch2', '02-chapter-2'],
            ch3:        ['chapter-3', 'chapter-03', 'Chapter-3', 'Chapter 3', 'ch3', '03-chapter-3'],
            ch4:        ['chapter-4', 'chapter-04', 'Chapter-4', 'Chapter 4', 'ch4', '04-chapter-4'],
            ch5:        ['chapter-5', 'chapter-05', 'Chapter-5', 'Chapter 5', 'ch5', '05-chapter-5'],
            ch6:        ['chapter-6', 'chapter-06', 'Chapter-6', 'Chapter 6', 'ch6', '06-chapter-6'],
            ch7:        ['chapter-7', 'chapter-07', 'Chapter-7', 'Chapter 7', 'ch7', '07-chapter-7'],
            ch8:        ['chapter-8', 'chapter-08', 'Chapter-8', 'Chapter 8', 'ch8', '08-chapter-8'],
            ch9:        ['chapter-9', 'chapter-09', 'Chapter-9', 'Chapter 9', 'ch9', '09-chapter-9'],
            conclusion: ['conclusion', 'Conclusion', '10-conclusion', 'outro']
        };
        var folders = [
            'audiobook/ya-heard-me/',
            'audiobook/Ya Heard Me/',
            'audiobook/',
            'audio/ya-heard-me/',
            'audio/',
            'ya-heard-me/',
            ''
        ];
        var exts = ['.mp3', '.m4a', '.wav'];
        var paths = [];
        var fileNames = names[sectionId] || [];
        for (var f = 0; f < folders.length; f++) {
            for (var n = 0; n < fileNames.length; n++) {
                for (var e = 0; e < exts.length; e++) {
                    paths.push(folders[f] + fileNames[n] + exts[e]);
                }
            }
        }
        return paths;
    }

    var SECTIONS = [
        {
            id: 'intro',
            type: 'Introduction',
            title: 'A Wake-Up Call from One Divine Being to Another',
            duration: '~8 min',
            summary: 'Nazir shares the foundation that started everything \u2014 the moment that changed his life and his personal discovery of recognizing divine communication.',
            questions: [
                'What moments in your life have served as wake-up calls to deeper truth?',
                'How do you currently recognize divine communication in your own life?',
                'What foundation of truth resonates most strongly with you right now?'
            ],
            prompts: [
                'Write about a time when you felt called to awaken to a deeper truth. What triggered that moment?',
                'Reflect on how you currently distinguish between programmed thinking and divine revelation in your own experience.'
            ]
        },
        {
            id: 'ch1',
            type: 'Chapter 1',
            title: 'The Foundation of Truth',
            duration: '~12 min',
            summary: "Nazir's fascination with sunlight leads to divine revelations about reality, exposing moon landing deception and revealing his divine assignment through ancient wisdom.",
            questions: [
                'What aspects of mainstream reality have you questioned in your own awakening?',
                'How does sunlight or natural phenomena speak to you personally?',
                'What deceptions have you become aware of in your spiritual journey?'
            ],
            prompts: [
                'Write about a moment when you realized something you believed was not true. How did that revelation feel?',
                'Describe your relationship with sunlight and nature. What messages do they carry for you?'
            ]
        },
        {
            id: 'ch2',
            type: 'Chapter 2',
            title: 'The Cosmic Chess Board',
            duration: '~14 min',
            summary: "Understanding Hebrew creation reality, consciousness invoked into water, the sacred dome, and Enoch's revelation of the cosmic game board with directional navigation.",
            questions: [
                'How do you understand the relationship between consciousness and the physical world?',
                'What does the cosmic chess board mean to you in terms of your life strategy?',
                'How aware are you of directional energies and cosmic positioning?'
            ],
            prompts: [
                'Imagine your life as a cosmic chess game. What pieces are you moving? What is your strategy?',
                'Write about the relationship between your consciousness and the reality you experience daily.'
            ]
        },
        {
            id: 'ch3',
            type: 'Chapter 3',
            title: 'How the Lord Revealed the Sun as Divine Communication',
            duration: '~11 min',
            summary: 'Discovery of the true solar message system, daily and seasonal communications, prophetic revelation, and living by divine solar timing.',
            questions: [
                'Do you pay attention to solar cycles in your spiritual practice?',
                'How might understanding the sun as divine communication change your daily routine?',
                'What messages from nature have you been ignoring or missing?'
            ],
            prompts: [
                'Start observing the sun daily for one week. Journal what you notice and feel.',
                'Write about how seasonal changes mirror changes in your own life right now.'
            ]
        },
        {
            id: 'ch4',
            type: 'Chapter 4',
            title: 'My Awakening to Divine Creative Power',
            duration: '~13 min',
            summary: 'Witnessing manifestation in action, speaking from creative authority, understanding temporal power, and learning about misusing spiritual abilities.',
            questions: [
                'When have you witnessed your words creating reality?',
                'How do you currently speak about your desires and intentions?',
                'What have you learned about the responsible use of creative power?'
            ],
            prompts: [
                'Write about a time when something you spoke about manifested exactly as you said. What did you learn?',
                'List 10 things you want to create. Rewrite each as if it already exists, speaking from creative authority.'
            ]
        },
        {
            id: 'ch5',
            type: 'Chapter 5',
            title: 'How the Lord Revealed Sacred Rhythm to Me',
            duration: '~10 min',
            summary: 'Discovery of perfect timing, awakening to artificial time programming, the Enoch Calendar system, gate energies, and moon cycle mastery.',
            questions: [
                'How does artificial time (Gregorian calendar) affect your spiritual practice?',
                'What would change if you aligned with natural cosmic rhythms?',
                'How aware are you of energetic gates and optimal timing for actions?'
            ],
            prompts: [
                'Reflect on times when your timing felt perfect versus times when it felt off. What was different?',
                'Research the current moon phase. How does it relate to what is happening in your life?'
            ]
        },
        {
            id: 'ch6',
            type: 'Chapter 6',
            title: 'My Year Living in Divine Sacred Rhythm',
            duration: '~15 min',
            summary: 'Personal journey through cosmic timing \u2014 spring renewal, summer expansion, autumn wisdom, and complete cycle transformation.',
            questions: [
                'What season are you in right now (energetically, not just calendar)?',
                'How might honoring natural seasons change your approach to goals?',
                'What would a complete sacred year cycle look like for you?'
            ],
            prompts: [
                'Describe the energetic season you are currently experiencing. What is being planted, growing, harvested, or resting?',
                'Design your ideal sacred year. What would you do in each season?'
            ]
        },
        {
            id: 'ch7',
            type: 'Chapter 7',
            title: 'My Journey Walking Divine Truth in a Programmed World',
            duration: '~12 min',
            summary: 'Lessons about timing misalignment, divine patience, operating in the Gregorian world while staying true to sacred time, maintaining faith among skeptics.',
            questions: [
                'How do you navigate living spiritually in a materialistic world?',
                'What challenges have you faced when your timing does not match others\u2019 expectations?',
                'How do you maintain faith when manifestations do not appear instantly?'
            ],
            prompts: [
                'Write about a time when you stayed true to your spiritual knowing despite external pressure.',
                'How do you balance divine timing with worldly deadlines and expectations?'
            ]
        },
        {
            id: 'ch8',
            type: 'Chapter 8',
            title: 'The Intertwining of Flesh and Spirit',
            duration: '~11 min',
            summary: 'Understanding our dual nature, biblical examples of spirit-flesh mastery, developing spiritual senses, meditation as conscious sleep, living as a conscious bridge.',
            questions: [
                'How integrated are your spiritual and physical selves?',
                'What spiritual senses are you developing or want to develop?',
                'How comfortable are you operating in both spiritual and physical realms simultaneously?'
            ],
            prompts: [
                'Describe a moment when you felt fully integrated \u2014 spirit and flesh working as one.',
                'What spiritual senses are calling to be developed in you? How can you practice them?'
            ]
        },
        {
            id: 'ch9',
            type: 'Chapter 9',
            title: 'The Mind of Generational Wealth',
            duration: '~13 min',
            summary: 'Understanding true wealth beyond money, shifting to generational thinking, wealth as consciousness in motion, building systems that serve others.',
            questions: [
                'How do you define wealth in your life?',
                'What legacy are you building for future generations?',
                'How can your consciousness create wealth that serves beyond yourself?'
            ],
            prompts: [
                'List all the ways you are already wealthy. Go beyond money.',
                'Write a letter to your great-great-grandchildren. What legacy are you creating for them?'
            ]
        },
        {
            id: 'conclusion',
            type: 'Conclusion',
            title: 'Integration and Next Steps',
            duration: '~6 min',
            summary: 'Final integration of the journey and stepping into your divine assignment.',
            questions: [
                'What is your biggest takeaway from this awakening journey?',
                'How will you apply these truths in your daily life?',
                'What is your next step in your divine assignment?'
            ],
            prompts: [
                'Write a letter to yourself summarizing your journey through Ya Heard Me. What has shifted?',
                'Declare your divine assignment based on what you have learned. What are you here to do?'
            ]
        }
    ];

    // ─── STATE ───────────────────────────────────────────────────────
    var sectionsCompleted = [];
    var currentUser = null;
    var db = null;
    var storageRef = null;
    var audioUrlCache = {};
    var currentlyPlaying = null;

    // ─── INIT ────────────────────────────────────────────────────────
    document.addEventListener('DOMContentLoaded', boot);

    function boot() {
        console.log('🌅 Phase 1: Awakening — booting…');
        waitForFirebase().then(function () {
            firebase.auth().onAuthStateChanged(handleAuth);
        });
    }

    function waitForFirebase() {
        return new Promise(function (resolve) {
            if (typeof firebase !== 'undefined' && firebase.auth && firebase.firestore) {
                return resolve();
            }
            var tries = 0;
            var id = setInterval(function () {
                tries++;
                if (typeof firebase !== 'undefined' && firebase.auth && firebase.firestore) {
                    clearInterval(id);
                    resolve();
                } else if (tries > 80) {
                    clearInterval(id);
                    showFatalError('Firebase failed to load. Please refresh the page.');
                }
            }, 100);
        });
    }

    async function handleAuth(firebaseUser) {
        if (!firebaseUser) {
            window.location.href = 'index.html';
            return;
        }

        currentUser = firebaseUser;
        db = firebase.firestore();

        if (typeof firebase.storage === 'function') {
            storageRef = firebase.storage().ref();
        }

        console.log('✅ Authenticated:', currentUser.email);

        try {
            await loadProgress();
        } catch (e) {
            console.warn('⚠️ Could not load progress — starting fresh', e);
            sectionsCompleted = [];
        }

        renderSections();
        updateProgressUI();

        hide('loadingState');
        show('mainContent');
    }

    // ─── PROGRESS (Firestore) ────────────────────────────────────────
    async function loadProgress() {
        var ref = db.collection('users').doc(currentUser.uid)
                    .collection('journey_progress').doc('current');
        var snap = await ref.get();
        if (snap.exists) {
            var data = snap.data();
            sectionsCompleted = (data.phase1_awakening && data.phase1_awakening.sections_completed) || [];
        } else {
            sectionsCompleted = [];
        }
        console.log('📊 Progress:', sectionsCompleted.length, '/', TOTAL_SECTIONS);
    }

    async function saveProgress() {
        var pct = Math.round((sectionsCompleted.length / TOTAL_SECTIONS) * 100);
        var status = pct === 100 ? 'completed' : (sectionsCompleted.length > 0 ? 'in_progress' : 'not_started');

        var ref = db.collection('users').doc(currentUser.uid)
                    .collection('journey_progress').doc('current');

        await ref.set({
            phase1_awakening: {
                sections_completed: sectionsCompleted,
                completion_percentage: pct,
                status: status,
                last_updated: firebase.firestore.FieldValue.serverTimestamp()
            },
            current_phase: pct === 100 ? 2 : 1
        }, { merge: true });
    }

    // ─── AUDIO URL RESOLUTION ────────────────────────────────────────
    async function resolveAudioUrl(sectionId) {
        if (audioUrlCache[sectionId]) return audioUrlCache[sectionId];

        // 1) Firebase Storage — try multiple path patterns
        if (storageRef) {
            var candidates = getStoragePathCandidates(sectionId);
            for (var i = 0; i < candidates.length; i++) {
                try {
                    var url = await storageRef.child(candidates[i]).getDownloadURL();
                    audioUrlCache[sectionId] = url;
                    console.log('\ud83d\udd25 Audio from Firebase Storage:', candidates[i]);
                    return url;
                } catch (_) { /* try next path */ }
            }
            console.log('\u26a0\ufe0f No Storage match for', sectionId, '— trying Drive fallback');
        }

        // 2) Google Drive fallback
        if (DRIVE_IDS[sectionId]) {
            var driveUrl = 'https://drive.google.com/uc?id=' + DRIVE_IDS[sectionId] + '&export=download';
            audioUrlCache[sectionId] = driveUrl;
            console.log('\ud83d\udcc1 Audio from Google Drive:', sectionId);
            return driveUrl;
        }

        return null;
    }

    // ─── RENDER ──────────────────────────────────────────────────────
    function renderSections() {
        var container = document.getElementById('sectionsContainer');
        if (!container) return;

        container.innerHTML = SECTIONS.map(function (sec, idx) {
            var done = sectionsCompleted.indexOf(sec.id) !== -1;
            var statusClass = done ? 'completed' : '';
            var sectionNum = idx + 1;

            return [
            '<div class="chapter-card ', statusClass, '" id="card-', sec.id, '" data-section="', sec.id, '">',

                '<div class="chapter-header" onclick="window.__p1.toggle(\'', sec.id, '\')">',
                    '<div class="chapter-number">', sectionNum, '</div>',
                    '<div class="chapter-info">',
                        '<h3 class="chapter-title">', sec.type, ': ', sec.title, '</h3>',
                        '<span class="chapter-duration">\ud83d\udd50 ', sec.duration, '</span>',
                    '</div>',
                    '<div class="chapter-status" id="status-', sec.id, '">',
                        done ? '\u2705 Complete' : '\u2b55 Not Started',
                    '</div>',
                '</div>',

                '<div class="chapter-content collapsed" id="content-', sec.id, '">',

                    '<div class="content-section">',
                        '<h4>\ud83d\udcd6 Summary</h4>',
                        '<p>', sec.summary, '</p>',
                    '</div>',

                    '<div class="content-section audio-section">',
                        '<h4>\ud83c\udfa7 Listen</h4>',
                        '<div class="inline-player" id="player-wrap-', sec.id, '">',
                            '<button class="play-btn" id="play-btn-', sec.id, '" onclick="window.__p1.playAudio(\'', sec.id, '\')">',
                                '\u25b6 Play Chapter',
                            '</button>',
                            '<audio id="audio-', sec.id, '" preload="none"></audio>',
                            '<div class="audio-status" id="audio-status-', sec.id, '"></div>',
                        '</div>',
                    '</div>',

                    '<div class="content-section">',
                        '<h4>\ud83d\udcad Reflection Questions</h4>',
                        '<ol class="reflection-list">',
                            sec.questions.map(function (q) { return '<li>' + q + '</li>'; }).join(''),
                        '</ol>',
                    '</div>',

                    '<div class="content-section">',
                        '<h4>\u270f\ufe0f Journal Prompts</h4>',
                        sec.prompts.map(function (p, pi) {
                            return [
                            '<div class="prompt-card">',
                                '<p><strong>Prompt ', (pi + 1), ':</strong> ', p, '</p>',
                                '<button class="journal-btn" onclick="window.__p1.openJournal(\'', escAttr(sec.title + ' \u2014 Prompt ' + (pi + 1)), '\')">',
                                    '\ud83d\udcd3 Write in Journal \u2192',
                                '</button>',
                            '</div>'
                            ].join('');
                        }).join(''),
                    '</div>',

                    '<div class="chapter-actions">',
                        done
                            ? '<span class="badge-done">\u2705 Section Completed</span>'
                            : '<button class="mark-done-btn" id="done-btn-' + sec.id + '" onclick="window.__p1.markDone(\'' + sec.id + '\')">\u2713 Mark Complete</button>',
                    '</div>',

                '</div>',

                '<button class="expand-btn" id="toggle-', sec.id, '" onclick="window.__p1.toggle(\'', sec.id, '\')">',
                    'Show Details \u25bc',
                '</button>',

            '</div>'
            ].join('');
        }).join('');
    }

    // ─── INTERACTIONS ────────────────────────────────────────────────
    function toggle(sectionId) {
        var content = document.getElementById('content-' + sectionId);
        var btn     = document.getElementById('toggle-' + sectionId);
        if (!content || !btn) return;

        var wasCollapsed = content.classList.contains('collapsed');
        content.classList.toggle('collapsed');
        btn.textContent = wasCollapsed ? 'Hide Details \u25b2' : 'Show Details \u25bc';
    }

    async function playAudio(sectionId) {
        var btn    = document.getElementById('play-btn-' + sectionId);
        var audio  = document.getElementById('audio-' + sectionId);
        var status = document.getElementById('audio-status-' + sectionId);
        if (!audio || !btn) return;

        // Pause if playing
        if (currentlyPlaying === sectionId && !audio.paused) {
            audio.pause();
            btn.textContent = '\u25b6 Resume';
            return;
        }

        // Resume if paused
        if (currentlyPlaying === sectionId && audio.paused && audio.currentTime > 0) {
            audio.play();
            btn.textContent = '\u23f8 Pause';
            return;
        }

        // Stop other audio
        if (currentlyPlaying && currentlyPlaying !== sectionId) {
            var oldAudio = document.getElementById('audio-' + currentlyPlaying);
            var oldBtn   = document.getElementById('play-btn-' + currentlyPlaying);
            if (oldAudio) { oldAudio.pause(); oldAudio.currentTime = 0; }
            if (oldBtn) oldBtn.textContent = '\u25b6 Play Chapter';
        }

        btn.textContent = '\u23f3 Loading\u2026';
        if (status) status.textContent = '';

        try {
            var url = await resolveAudioUrl(sectionId);
            if (!url) {
                btn.textContent = '\u25b6 Play Chapter';
                if (status) status.textContent = '\u26a0\ufe0f Audio not available \u2014 listen on Spotify';
                return;
            }

            audio.src = url;
            audio.load();

            audio.oncanplay = function () {
                audio.play();
                btn.textContent = '\u23f8 Pause';
                currentlyPlaying = sectionId;
            };

            audio.ontimeupdate = function () {
                if (status) {
                    status.textContent = formatTime(audio.currentTime) + ' / ' + formatTime(audio.duration);
                }
            };

            audio.onended = function () {
                btn.textContent = '\ud83d\udd04 Replay';
                currentlyPlaying = null;
                if (sectionsCompleted.indexOf(sectionId) === -1) {
                    toast('Finished listening? Click "Mark Complete" to track your progress!', 'info');
                }
            };

            audio.onerror = function () {
                btn.textContent = '\u25b6 Play Chapter';
                if (status) status.textContent = '\u26a0\ufe0f Could not load audio \u2014 try Spotify';
                currentlyPlaying = null;
            };

        } catch (e) {
            console.error('Audio load error:', e);
            btn.textContent = '\u25b6 Play Chapter';
            if (status) status.textContent = '\u26a0\ufe0f Audio error \u2014 listen on Spotify';
        }
    }

    async function markDone(sectionId) {
        if (sectionsCompleted.indexOf(sectionId) !== -1) {
            toast('Already completed!', 'info');
            return;
        }

        sectionsCompleted.push(sectionId);

        try {
            await saveProgress();
        } catch (e) {
            console.error('Save error:', e);
            toast('Could not save \u2014 try again', 'error');
            sectionsCompleted = sectionsCompleted.filter(function (s) { return s !== sectionId; });
            return;
        }

        var card    = document.getElementById('card-' + sectionId);
        var statusEl = document.getElementById('status-' + sectionId);
        var doneBtn = document.getElementById('done-btn-' + sectionId);

        if (card)    card.classList.add('completed');
        if (statusEl) statusEl.innerHTML = '\u2705 Complete';
        if (doneBtn) doneBtn.outerHTML = '<span class="badge-done">\u2705 Section Completed</span>';

        updateProgressUI();
        toast('Section completed! \ud83c\udf89', 'success');

        if (window.progressSystem && typeof window.progressSystem.awardXP === 'function') {
            window.progressSystem.awardXP(50, 'Completed Ya Heard Me section', 'journey');
        }

        if (sectionsCompleted.length === TOTAL_SECTIONS) {
            celebrateCompletion();
        }
    }

    function openJournal(promptTitle) {
        window.location.href = 'members-new.html#journal?prompt=' + encodeURIComponent(promptTitle);
    }

    // ─── UI HELPERS ──────────────────────────────────────────────────
    function updateProgressUI() {
        var pct = Math.round((sectionsCompleted.length / TOTAL_SECTIONS) * 100);
        setText('progressPercentage', pct + '%');
        setText('progressText', sectionsCompleted.length + ' of ' + TOTAL_SECTIONS + ' sections completed');
        setText('unlockProgress', sectionsCompleted.length + '/' + TOTAL_SECTIONS + ' sections complete');

        var bar = document.getElementById('progressBar');
        if (bar) bar.style.width = pct + '%';
    }

    function celebrateCompletion() {
        if (typeof confetti === 'function') {
            confetti({ particleCount: 120, spread: 80, origin: { y: 0.6 } });
            setTimeout(function () { confetti({ particleCount: 60, angle: 60, spread: 55, origin: { x: 0 } }); }, 300);
            setTimeout(function () { confetti({ particleCount: 60, angle: 120, spread: 55, origin: { x: 1 } }); }, 500);
        }

        var overlay = document.createElement('div');
        overlay.className = 'completion-modal';
        overlay.innerHTML =
            '<div class="modal-content">' +
                '<h2>\ud83c\udf89 Phase 1 Complete!</h2>' +
                '<p>Congratulations! You have completed the <strong>Awakening</strong> phase of your journey through Ya Heard Me.</p>' +
                '<p><strong>Phase 2: Understanding</strong> is now unlocked!</p>' +
                '<div class="modal-actions">' +
                    '<button onclick="window.location.href=\'index.html\'" class="modal-btn secondary">Return Home</button>' +
                    '<button onclick="window.location.href=\'phase2-understanding.html\'" class="modal-btn primary">Begin Phase 2 \u2192</button>' +
                '</div>' +
            '</div>';
        document.body.appendChild(overlay);
    }

    function toast(message, type) {
        type = type || 'info';
        var el = document.createElement('div');
        el.className = 'toast toast-' + type;
        el.textContent = message;
        document.body.appendChild(el);
        requestAnimationFrame(function () { el.classList.add('show'); });
        setTimeout(function () {
            el.classList.remove('show');
            setTimeout(function () { el.remove(); }, 350);
        }, 3500);
    }

    function showFatalError(msg) {
        var el = document.getElementById('loadingState');
        if (el) {
            el.innerHTML =
                '<div style="text-align:center;color:#ef4444;">' +
                    '<p style="font-size:1.4rem;margin-bottom:1rem;">\u26a0\ufe0f</p>' +
                    '<p>' + msg + '</p>' +
                    '<button onclick="location.reload()" style="margin-top:1rem;padding:.75rem 1.5rem;background:#F59E0B;color:#fff;border:none;border-radius:10px;font-weight:600;cursor:pointer;">Reload</button>' +
                '</div>';
        }
    }

    function hide(id) { var el = document.getElementById(id); if (el) el.style.display = 'none'; }
    function show(id) { var el = document.getElementById(id); if (el) el.style.display = 'block'; }
    function setText(id, txt) { var el = document.getElementById(id); if (el) el.textContent = txt; }
    function formatTime(s) {
        if (!s || isNaN(s)) return '0:00';
        var m = Math.floor(s / 60);
        var sec = Math.floor(s % 60);
        return m + ':' + (sec < 10 ? '0' : '') + sec;
    }
    function escAttr(str) { return str.replace(/'/g, "\\'").replace(/"/g, '&quot;'); }

    // ─── PUBLIC API ──────────────────────────────────────────────────
    window.__p1 = {
        toggle:      toggle,
        playAudio:   playAudio,
        markDone:    markDone,
        openJournal: openJournal
    };

})();
