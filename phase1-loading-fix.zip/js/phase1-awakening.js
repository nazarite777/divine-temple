/**
 * Phase 1: Awakening — Ya Heard Me Audiobook Journey
 * 11 sections: Introduction + 9 Chapters + Conclusion
 * Audio: Firebase Storage → Google Drive fallback
 * Progress: Firestore users/{uid}/journey_progress/current
 * Responses: Firestore users/{uid}/journey_responses/phase1
 * Questions: From the Complete Divine Discernment Workbook
 */
(function () {
    'use strict';

    var TOTAL_SECTIONS = 11;

    /* ── Google Drive fallback IDs ────────────────────────────── */
    var DRIVE_IDS = {
        intro:      '1hwRwWKa7TcP6iXLP4fia7A9Hg7CN8vSS',
        ch1:        '1xjGZAE9e_B7FGMqtW-ujp7gCT5pEk9wc',
        ch2:        '1qxlYoLaYI_8iyOWkP7NrS2XOphrtKFOX',
        ch3:        '1PrIRPymEsnlMx9G7vL0htbpSsM8MN0_s',
        ch4:        '1fNWY8-cyWLPOmmy5QmQGrMu6aXRiF5wC',
        ch5:        '1dqTo_AgYH6Rtvmii5L2EonHe7dXYDV74',
        ch6:        '172xFi6l6U0cXerrjQPvK7tou3_WdPSpb',
        ch7:        '1N6xlY7UAjuU3i3pCdX0-uCXUFuXzlRYr',
        ch8:        '1q7bJgZkNXRutSu-PrKSERQBlkR8aLF0x',
        ch9:        '1mS-shUXhHfiP9cdI_spbDny8LXLg64XN',
        conclusion: '1UO1IuinGpvsp3uYZqJmE-a8p9nl5dyfM'
    };

    /* ── Firebase Storage path candidates ─────────────────────── */
    function getStoragePaths(id) {
        var names = {
            intro: ['Introduction', 'introduction', 'Intro', 'intro', '00-Introduction', '00_Introduction'],
            ch1: ['Chapter-1', 'Chapter_1', 'chapter-1', 'Ch-1', 'Ch1', '01-Chapter-1', 'Chapter 1'],
            ch2: ['Chapter-2', 'Chapter_2', 'chapter-2', 'Ch-2', 'Ch2', '02-Chapter-2', 'Chapter 2'],
            ch3: ['Chapter-3', 'Chapter_3', 'chapter-3', 'Ch-3', 'Ch3', '03-Chapter-3', 'Chapter 3'],
            ch4: ['Chapter-4', 'Chapter_4', 'chapter-4', 'Ch-4', 'Ch4', '04-Chapter-4', 'Chapter 4'],
            ch5: ['Chapter-5', 'Chapter_5', 'chapter-5', 'Ch-5', 'Ch5', '05-Chapter-5', 'Chapter 5'],
            ch6: ['Chapter-6', 'Chapter_6', 'chapter-6', 'Ch-6', 'Ch6', '06-Chapter-6', 'Chapter 6'],
            ch7: ['Chapter-7', 'Chapter_7', 'chapter-7', 'Ch-7', 'Ch7', '07-Chapter-7', 'Chapter 7'],
            ch8: ['Chapter-8', 'Chapter_8', 'chapter-8', 'Ch-8', 'Ch8', '08-Chapter-8', 'Chapter 8'],
            ch9: ['Chapter-9', 'Chapter_9', 'chapter-9', 'Ch-9', 'Ch9', '09-Chapter-9', 'Chapter 9'],
            conclusion: ['Conclusion', 'conclusion', '10-Conclusion', '10_Conclusion']
        };
        var variants = names[id] || [id];
        var folders = ['audiobook/', 'audiobooks/', 'ya-heard-me/', 'Ya-Heard-Me/', 'audio/', 'Audio/', 'ya_heard_me/', ''];
        var exts = ['.mp3', '.m4a', '.wav', '.ogg', '.aac'];
        var paths = [];
        for (var f = 0; f < folders.length; f++)
            for (var v = 0; v < variants.length; v++)
                for (var e = 0; e < exts.length; e++)
                    paths.push(folders[f] + variants[v] + exts[e]);
        return paths;
    }

    /* ── CHAPTER DATA — workbook questions ────────────────────── */
    var SECTIONS = [
        {
            id: 'intro', type: 'Introduction', title: 'Your Awakening Begins', duration: '~8 min',
            summary: 'Welcome to "Ya Heard Me" \u2014 a journey from programming to divine truth. This introduction sets the stage for your complete transformation through direct spiritual experience.',
            questions: [
                'What drew you to begin this spiritual awakening journey?',
                'How has meditation affected your ability to discern truth from programming?',
                'What changes in perception have you noticed in daily life since beginning meditation?',
                'How has your relationship with intuitive guidance evolved through this practice?'
            ],
            prompts: [
                'Write about a time when you felt called to awaken to a deeper truth. What triggered that moment?',
                'Reflect on how you currently distinguish between programmed thinking and divine revelation in your own experience.'
            ]
        },
        {
            id: 'ch1', type: 'Chapter 1', title: 'The Foundation of Truth', duration: '~12 min',
            summary: "Nazir's fascination with sunlight leads to divine revelations about reality, exposing deceptions and revealing his divine assignment through ancient wisdom.",
            questions: [
                'What aspects of sunlight have you found most captivating?',
                'Describe a time when you observed sunlight breaking through clouds. What did you actually see (not what you\'ve been taught about light)?',
                'Have you ever had a moment of revelation while observing natural phenomena? Describe it.',
                'What would it cost you personally (relationships, identity, security) if you discovered a fundamental truth about reality that contradicted mainstream understanding?',
                'How do you distinguish between imagination, delusion, and genuine spiritual insight? What criteria do you use?'
            ],
            prompts: [
                'Write about a moment when you realized something you believed was not true. How did that revelation feel?',
                'If you asked, "What did you put on Earth to fight against these wrongs?" what answer resonates within you? What divine assignment might you be here to fulfill?'
            ]
        },
        {
            id: 'ch2', type: 'Chapter 2', title: 'The Cosmic Chess Board', duration: '~14 min',
            summary: "Understanding Hebrew creation reality, consciousness invoked into water, the sacred dome, and Enoch's revelation of the cosmic game board with directional navigation.",
            questions: [
                'How have you observed plants and animals demonstrating knowledge or intelligence that humans often overlook?',
                'What patterns do you notice in plant growth?',
                'What cycles or rhythms become apparent when you sit in nature?',
                'How might water be carrying consciousness between you and living systems?',
                'How many steps separate you from cosmic systems? How many from water cycles?'
            ],
            prompts: [
                'Imagine your life as a cosmic chess game. What pieces are you moving? What is your strategy?',
                'Find a comfortable spot in nature for 30 minutes. Document the patterns, rhythms, and interconnections you observe.'
            ]
        },
        {
            id: 'ch3', type: 'Chapter 3', title: 'How the Lord Revealed the Sun as Divine Communication', duration: '~11 min',
            summary: 'Discovery of the true solar message system, daily and seasonal communications, prophetic revelation, and living by divine solar timing.',
            questions: [
                'How might understanding the sun as a communication system rather than just a light source change your daily relationship with it?',
                'How might ancient cultures that built solar temples have understood something about cosmic communication that modern society has forgotten?',
                'What patterns have you noticed in your own life that correlate with solar cycles (seasonal changes, time of day)?',
                'If the sun is a communication system, what might it be communicating to you specifically?'
            ],
            prompts: [
                'Start observing the sun daily for one week. Journal what you notice, feel, and intuit each morning.',
                'Create a 7-day solar observation journal: track sunrise location, quality of light, your intuitive "message" for the day, and evening reflection on how it related to your day.'
            ]
        },
        {
            id: 'ch4', type: 'Chapter 4', title: 'My Awakening to Divine Creative Power', duration: '~13 min',
            summary: 'Witnessing manifestation in action, speaking from creative authority, understanding temporal power, and learning about misusing spiritual abilities.',
            questions: [
                'Have you ever experienced a "miraculous" manifestation in your life, especially as a child?',
                'What did that experience teach you about your connection to divine creative power?',
                'Which type of language do you typically use \u2014 past-focused, present-focused, or future-creating? Provide examples from your own speech.',
                'What is the difference between using manifestation for service versus ego gratification?',
                'How might your manifestation work change if you focused on creating systems that benefit multiple generations?'
            ],
            prompts: [
                'Write about a time when something you spoke about manifested exactly as you said. What did you learn?',
                'List 10 things you want to create. Rewrite each as if it already exists, speaking from creative authority.'
            ]
        },
        {
            id: 'ch5', type: 'Chapter 5', title: 'How the Lord Revealed Sacred Rhythm to Me', duration: '~10 min',
            summary: 'Discovery of perfect timing, awakening to artificial time programming, the Enoch Calendar system, gate energies, and moon cycle mastery.',
            questions: [
                'Who really decided what time is? Who gave institutions the authority to tell us when seconds start and stop?',
                'How has artificial time programming affected your connection to natural rhythms?',
                'Do you notice your body following internal rhythms regardless of clock time? What patterns have you observed?',
                'How did time feel different without mechanical measurement?',
                'How might your relationship with time change if you followed a calendar system aligned with natural cycles?'
            ],
            prompts: [
                'Reflect on times when your timing felt perfect versus times when it felt off. What was different?',
                'For one week, track your energy levels every 2 hours. Note correlations with natural cycles (moon phases, daylight duration).'
            ]
        },
        {
            id: 'ch6', type: 'Chapter 6', title: 'My Year Living in Divine Sacred Rhythm', duration: '~15 min',
            summary: 'Personal journey through cosmic timing \u2014 spring renewal, summer expansion, autumn wisdom, and complete cycle transformation.',
            questions: [
                'What energetic season are you in right now (not just calendar)?',
                'How might honoring natural seasons change your approach to goals and projects?',
                'What have you had to sacrifice on your spiritual journey so far?',
                'What further sacrifices might be necessary if you fully committed to your spiritual truth?'
            ],
            prompts: [
                'Describe the energetic season you are currently experiencing. What is being planted, growing, harvested, or resting?',
                'Design your ideal sacred year. What would you do in each season?'
            ]
        },
        {
            id: 'ch7', type: 'Chapter 7', title: 'My Journey Walking Divine Truth in a Programmed World', duration: '~12 min',
            summary: 'Lessons about timing misalignment, divine patience, operating in the Gregorian world while staying true to sacred time, maintaining faith among skeptics.',
            questions: [
                'What insights wanted to be shared but were better held in silence?',
                'How did restraint affect the energy of your interactions?',
                'When did silence feel appropriate versus when did it feel like fear?',
                'How did others respond to your listening versus your explaining?',
                'How do you balance divine timing with worldly deadlines and expectations?'
            ],
            prompts: [
                'Write about a time when you stayed true to your spiritual knowing despite external pressure.',
                'For one week, practice strategic silence about your spiritual insights. Document what happens.'
            ]
        },
        {
            id: 'ch8', type: 'Chapter 8', title: 'The Intertwining of Flesh and Spirit', duration: '~11 min',
            summary: 'Understanding our dual nature, biblical examples of spirit-flesh mastery, developing spiritual senses, meditation as conscious sleep, living as a conscious bridge.',
            questions: [
                'How does your spirit perceive your challenges and struggles differently than your flesh?',
                'How does your spirit perceive your purpose and potential?',
                'How long could you maintain conscious awareness while physically relaxed?',
                'What sensations arose that were different from normal waking or sleeping states?',
                'What insights do biblical accounts give you about the relationship between spiritual and physical realms?'
            ],
            prompts: [
                'Describe a moment when you felt fully integrated \u2014 spirit and flesh working as one.',
                'Practice maintaining awareness of both physical and spiritual dimensions during three ordinary activities. Document what additional information becomes available.'
            ]
        },
        {
            id: 'ch9', type: 'Chapter 9', title: 'The Mind of Generational Wealth', duration: '~13 min',
            summary: 'Understanding true wealth beyond money, shifting to generational thinking, wealth as consciousness in motion, building systems that serve others.',
            questions: [
                'How does defining wealth as "the capacity to create prosperity for others" differ from conventional understanding?',
                'How might this perspective change your financial goals and strategies?',
                'What skills, knowledge, or resources do you currently possess that could form the foundation of a generational wealth system?',
                'If financial abundance is a form of crystallized consciousness, how might aligning with your spiritual purpose affect your ability to manifest wealth?',
                'How might your divine assignment operate at the personal, family, community, and generational levels?'
            ],
            prompts: [
                'List all the ways you are already wealthy. Go beyond money.',
                'Write a letter to your great-great-grandchildren. What legacy are you creating for them?'
            ]
        },
        {
            id: 'conclusion', type: 'Conclusion', title: 'Your Divine Declaration', duration: '~6 min',
            summary: 'Final integration of the journey \u2014 declaring your divine assignment and stepping fully into awakened living.',
            questions: [
                'What perspectives have shifted most significantly for you?',
                'What new capabilities are you developing?',
                'What resistance have you encountered (internal and external)?',
                'How has your sense of purpose evolved?',
                'What does living as a divine being mean to you now?'
            ],
            prompts: [
                'Write a letter to yourself summarizing your journey through Ya Heard Me. What has shifted?',
                'Declare your divine assignment based on what you have learned. What are you here to do?'
            ]
        }
    ];

    /* ── STATE ────────────────────────────────────────────────── */
    var sectionsCompleted = [];
    var responses = {};          // { 'ch1_q0': 'answer text', ... }
    var currentUser = null;
    var db = null;
    var storageRef = null;
    var audioUrlCache = {};
    var currentlyPlaying = null;
    var contentRendered = false;
    var saveTimers = {};         // debounce timers per field

    /* ── BOOT ─────────────────────────────────────────────────── */
    // Boot immediately since script is at bottom of body (DOM already ready)
    // Also register DOMContentLoaded as fallback in case script loads early
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }

    // Global safety net: if ANY unhandled error occurs, still show content
    window.addEventListener('error', function () {
        setTimeout(function () { if (!contentRendered) renderAndShow(); }, 2000);
    });

    function boot() {
        console.log('[P1] Phase 1: Awakening — booting');
        // FAILSAFE: Show content no matter what after 10 seconds
        setTimeout(function () {
            if (!contentRendered) {
                console.warn('[P1] Failsafe: rendering now');
                renderAndShow();
            }
        }, 10000);

        waitForFirebase().then(function () {
            console.log('[P1] Firebase ready');
            try { firebase.auth().onAuthStateChanged(handleAuth); }
            catch (e) { console.error('[P1] Auth listener failed:', e); renderAndShow(); }
        }).catch(function (e) {
            console.warn('[P1] Firebase not available:', e);
            renderAndShow();
        });
    }

    function waitForFirebase() {
        return new Promise(function (resolve, reject) {
            if (typeof firebase !== 'undefined' && firebase.auth && firebase.firestore) return resolve();
            var tries = 0;
            var id = setInterval(function () {
                tries++;
                if (typeof firebase !== 'undefined' && firebase.auth && firebase.firestore) { clearInterval(id); resolve(); }
                else if (tries > 80) { clearInterval(id); reject(); }
            }, 100);
        });
    }

    /* ── AUTH ──────────────────────────────────────────────────── */
    async function handleAuth(firebaseUser) {
        console.log('[P1] Auth:', firebaseUser ? firebaseUser.email : 'none');
        var overlay = document.getElementById('accessDeniedOverlay');
        var loading = document.getElementById('loadingState');

        if (!firebaseUser) {
            if (overlay) overlay.style.display = 'flex';
            if (loading) loading.style.display = 'none';
            return;
        }

        currentUser = firebaseUser;

        try {
            db = firebase.firestore();
        } catch (e) {
            console.error('[P1] Firestore init failed:', e);
            renderAndShow();
            return;
        }

        // Check premium — with full error recovery
        var isPremium = false;
        try {
            isPremium = await Promise.race([
                checkPremium(),
                new Promise(function (_, rej) { setTimeout(function () { rej(new Error('timeout')); }, 8000); })
            ]);
        } catch (e) {
            console.warn('[P1] Premium check failed:', e.message);
            // Admin email override as fallback
            var adminEmails = ['cbevvv@gmail.com'];
            if (currentUser.email && adminEmails.indexOf(currentUser.email.toLowerCase()) !== -1) {
                isPremium = true;
                console.log('[P1] Admin override granted');
            }
        }

        if (!isPremium) {
            console.log('[P1] Not premium — showing gate');
            if (overlay) overlay.style.display = 'flex';
            if (loading) loading.style.display = 'none';
            return;
        }

        // Premium confirmed
        console.log('[P1] Premium confirmed — loading content');
        if (overlay) overlay.style.display = 'none';
        try { if (typeof firebase.storage === 'function') storageRef = firebase.storage().ref(); } catch (e) {}

        // Load progress + responses — failures are fine, just start fresh
        try {
            await Promise.race([
                Promise.all([loadProgress(), loadResponses()]),
                new Promise(function (_, rej) { setTimeout(function () { rej(); }, 6000); })
            ]);
        } catch (e) {
            console.warn('[P1] Data load partial/failed — starting fresh');
            if (!sectionsCompleted.length) sectionsCompleted = [];
        }

        renderAndShow();
    }

    async function checkPremium() {
        var userDoc = await db.collection('users').doc(currentUser.uid).get();
        var d = userDoc.exists ? userDoc.data() : {};
        var ok = d.isPremium || d.membershipStatus === 'premium' || d.paymentVerified ||
                 d.premium === true || d.premium_status === 'active' ||
                 d.membershipLevel === 'premium' || d.membershipLevel === 'admin' ||
                 d.role === 'admin' || d.journey_access === true || d.all_features_unlocked === true;
        var adminEmails = ['cbevvv@gmail.com'];
        if (currentUser.email && adminEmails.indexOf(currentUser.email.toLowerCase()) !== -1) ok = true;
        return ok;
    }

    /* ── RENDER ───────────────────────────────────────────────── */
    function renderAndShow() {
        if (contentRendered) return;
        contentRendered = true;
        try {
            renderSections();
            updateProgressUI();
        } catch (e) {
            console.error('[P1] Render error:', e);
            // Even if renderSections fails, show mainContent so page isn't stuck
            var container = document.getElementById('sectionsContainer');
            if (container) container.innerHTML = '<p style="color:#F59E0B;text-align:center;padding:2rem;">Content loading error. Please refresh the page.</p>';
        }
        var ld = document.getElementById('loadingState');
        var mn = document.getElementById('mainContent');
        if (ld) ld.style.display = 'none';
        if (mn) mn.style.display = 'block';
        console.log('[P1] Content rendered ✅');
    }

    /* ── PROGRESS ─────────────────────────────────────────────── */
    async function loadProgress() {
        var snap = await db.collection('users').doc(currentUser.uid)
                           .collection('journey_progress').doc('current').get();
        if (snap.exists) {
            var data = snap.data();
            sectionsCompleted = (data.phase1_awakening && data.phase1_awakening.sections_completed) || [];
        }
        console.log('[P1] Progress:', sectionsCompleted.length, '/', TOTAL_SECTIONS);
    }

    async function saveProgress() {
        if (!db || !currentUser) return;
        var pct = Math.round((sectionsCompleted.length / TOTAL_SECTIONS) * 100);
        try {
            await db.collection('users').doc(currentUser.uid)
                     .collection('journey_progress').doc('current')
                     .set({
                         phase1_awakening: {
                             sections_completed: sectionsCompleted,
                             completion_percentage: pct,
                             status: pct === 100 ? 'completed' : (sectionsCompleted.length > 0 ? 'in_progress' : 'not_started'),
                             last_updated: firebase.firestore.FieldValue.serverTimestamp()
                         },
                         current_phase: pct === 100 ? 2 : 1
                     }, { merge: true });
        } catch (e) { console.warn('[P1] Save progress failed:', e.message); }
    }

    /* ── RESPONSES (per-question answers) ─────────────────────── */
    async function loadResponses() {
        var snap = await db.collection('users').doc(currentUser.uid)
                           .collection('journey_responses').doc('phase1').get();
        if (snap.exists) {
            responses = snap.data() || {};
        }
        var count = Object.keys(responses).filter(function (k) { return responses[k] && responses[k].trim(); }).length;
        console.log('[P1] Loaded', count, 'responses');
    }

    function saveResponse(fieldKey, value) {
        if (!db || !currentUser) return;

        responses[fieldKey] = value;

        // Show saving indicator
        var indicator = document.getElementById('save-' + fieldKey);
        if (indicator) { indicator.textContent = 'Saving...'; indicator.className = 'save-indicator saving'; }

        // Debounce: save after 1.5s of inactivity
        if (saveTimers[fieldKey]) clearTimeout(saveTimers[fieldKey]);
        saveTimers[fieldKey] = setTimeout(function () {
            var update = {};
            update[fieldKey] = value;
            update['last_updated'] = firebase.firestore.FieldValue.serverTimestamp();

            db.collection('users').doc(currentUser.uid)
              .collection('journey_responses').doc('phase1')
              .set(update, { merge: true })
              .then(function () {
                  if (indicator) { indicator.textContent = '\u2713 Saved'; indicator.className = 'save-indicator saved'; }
                  updateAnswerProgress();
              })
              .catch(function (e) {
                  console.warn('[P1] Save response failed:', e.message);
                  if (indicator) { indicator.textContent = 'Save failed'; indicator.className = 'save-indicator'; }
              });
        }, 1500);
    }

    function updateAnswerProgress() {
        SECTIONS.forEach(function (sec) {
            var total = sec.questions.length;
            var answered = 0;
            for (var qi = 0; qi < total; qi++) {
                var key = sec.id + '_q' + qi;
                if (responses[key] && responses[key].trim()) answered++;
            }
            var bar = document.getElementById('ans-bar-' + sec.id);
            var txt = document.getElementById('ans-txt-' + sec.id);
            if (bar) bar.style.width = (total > 0 ? Math.round((answered / total) * 100) : 0) + '%';
            if (txt) txt.textContent = answered + '/' + total + ' answered';
        });
    }

    /* ── AUDIO URL RESOLUTION ─────────────────────────────────── */
    async function resolveAudioUrl(sectionId) {
        if (audioUrlCache[sectionId]) return audioUrlCache[sectionId];
        if (storageRef) {
            var paths = getStoragePaths(sectionId);
            for (var i = 0; i < paths.length; i++) {
                try {
                    var url = await storageRef.child(paths[i]).getDownloadURL();
                    audioUrlCache[sectionId] = url;
                    return url;
                } catch (e) {}
            }
        }
        if (DRIVE_IDS[sectionId]) {
            var driveUrl = 'https://drive.google.com/uc?export=download&id=' + DRIVE_IDS[sectionId];
            audioUrlCache[sectionId] = driveUrl;
            return driveUrl;
        }
        return null;
    }

    /* ── RENDER SECTIONS ──────────────────────────────────────── */
    function renderSections() {
        var container = document.getElementById('sectionsContainer');
        if (!container) return;

        var html = '';
        for (var idx = 0; idx < SECTIONS.length; idx++) {
            var sec = SECTIONS[idx];
            var done = sectionsCompleted.indexOf(sec.id) !== -1;
            var num = idx + 1;

            // Count answers for this section
            var answeredCount = 0;
            for (var aq = 0; aq < sec.questions.length; aq++) {
                if (responses[sec.id + '_q' + aq] && responses[sec.id + '_q' + aq].trim()) answeredCount++;
            }

            html += '<div class="chapter-card ' + (done ? 'completed' : '') + '" id="card-' + sec.id + '">';

            // ── Header
            html += '<div class="chapter-header" onclick="window.__p1.toggle(\'' + sec.id + '\')">';
            html += '<div class="chapter-number">' + num + '</div>';
            html += '<div class="chapter-info">';
            html += '<h3 class="chapter-title">' + sec.type + ': ' + sec.title + '</h3>';
            html += '<span class="chapter-duration">\ud83d\udd50 ' + sec.duration;
            if (answeredCount > 0) html += ' &nbsp;\u270f\ufe0f ' + answeredCount + '/' + sec.questions.length;
            html += '</span>';
            html += '</div>';
            html += '<div class="chapter-status" id="status-' + sec.id + '">' + (done ? '\u2705 Complete' : '\u2b55 Not Started') + '</div>';
            html += '</div>';

            // ── Collapsible content
            html += '<div class="chapter-content collapsed" id="content-' + sec.id + '">';

            // Summary
            html += '<div class="content-section"><h4>\ud83d\udcd6 Summary</h4><p>' + sec.summary + '</p></div>';

            // Audio
            html += '<div class="content-section audio-section"><h4>\ud83c\udfa7 Listen</h4>';
            html += '<div class="inline-player" id="player-wrap-' + sec.id + '">';
            html += '<button class="play-btn" id="play-btn-' + sec.id + '" onclick="window.__p1.playAudio(\'' + sec.id + '\')">\u25b6 Play Chapter</button>';
            html += '<audio id="audio-' + sec.id + '" preload="none"></audio>';
            html += '<div class="audio-status" id="audio-status-' + sec.id + '"></div>';
            html += '</div></div>';

            // ── Reflection Questions WITH answer fields
            html += '<div class="content-section">';
            html += '<h4>\ud83d\udcad Reflection Questions</h4>';

            // Answer progress bar
            html += '<div class="answers-progress">';
            html += '<span id="ans-txt-' + sec.id + '">' + answeredCount + '/' + sec.questions.length + ' answered</span>';
            html += '<div class="answers-progress-bar"><div class="answers-progress-fill" id="ans-bar-' + sec.id + '" style="width:' + (sec.questions.length > 0 ? Math.round((answeredCount / sec.questions.length) * 100) : 0) + '%"></div></div>';
            html += '</div>';

            for (var qi = 0; qi < sec.questions.length; qi++) {
                var fieldKey = sec.id + '_q' + qi;
                var savedVal = responses[fieldKey] || '';
                var escapedVal = savedVal.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

                html += '<div class="question-block">';
                html += '<div class="question-text"><strong>' + (qi + 1) + '.</strong> ' + sec.questions[qi] + '</div>';
                html += '<textarea class="answer-area" id="ans-' + fieldKey + '" placeholder="Write your reflection here\u2026" '
                      + 'oninput="window.__p1.onAnswer(\'' + fieldKey + '\', this.value)" '
                      + 'onfocus="this.style.minHeight=\'120px\'">'
                      + escapedVal + '</textarea>';
                html += '<div class="answer-meta">';
                html += '<span class="save-indicator" id="save-' + fieldKey + '">' + (savedVal ? '\u2713 Saved' : '') + '</span>';
                html += '<span class="char-count" id="cc-' + fieldKey + '">' + (savedVal.length > 0 ? savedVal.length + ' chars' : '') + '</span>';
                html += '</div>';
                html += '</div>';
            }
            html += '</div>';

            // Journal prompts
            html += '<div class="content-section"><h4>\u270f\ufe0f Journal Prompts</h4>';
            for (var pi = 0; pi < sec.prompts.length; pi++) {
                var pKey = sec.id + '_p' + pi;
                var pVal = responses[pKey] || '';
                var pEsc = pVal.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

                html += '<div class="prompt-card">';
                html += '<p><strong>Prompt ' + (pi + 1) + ':</strong> ' + sec.prompts[pi] + '</p>';
                html += '<textarea class="answer-area" id="ans-' + pKey + '" placeholder="Journal your thoughts here\u2026" '
                      + 'oninput="window.__p1.onAnswer(\'' + pKey + '\', this.value)" '
                      + 'onfocus="this.style.minHeight=\'150px\'" style="min-height:100px;">'
                      + pEsc + '</textarea>';
                html += '<div class="answer-meta">';
                html += '<span class="save-indicator" id="save-' + pKey + '">' + (pVal ? '\u2713 Saved' : '') + '</span>';
                html += '<span class="char-count" id="cc-' + pKey + '">' + (pVal.length > 0 ? pVal.length + ' chars' : '') + '</span>';
                html += '</div>';
                html += '</div>';
            }
            html += '</div>';

            // Actions
            html += '<div class="chapter-actions">';
            if (done) {
                html += '<span class="badge-done">\u2705 Section Completed</span>';
            } else {
                html += '<button class="mark-done-btn" id="done-btn-' + sec.id + '" onclick="window.__p1.markDone(\'' + sec.id + '\')">\u2713 Mark Complete</button>';
            }
            html += '</div>';
            html += '</div>'; // end chapter-content

            html += '<button class="expand-btn" id="toggle-' + sec.id + '" onclick="window.__p1.toggle(\'' + sec.id + '\')">Show Details \u25bc</button>';
            html += '</div>'; // end chapter-card
        }

        container.innerHTML = html;
        console.log('[P1] Rendered', SECTIONS.length, 'cards with answer fields');
    }

    /* ── INTERACTIONS ─────────────────────────────────────────── */
    function toggle(sectionId) {
        var content = document.getElementById('content-' + sectionId);
        var btn = document.getElementById('toggle-' + sectionId);
        if (!content || !btn) return;
        if (content.classList.contains('collapsed')) {
            content.classList.remove('collapsed');
            btn.textContent = 'Hide Details \u25b2';
        } else {
            content.classList.add('collapsed');
            btn.textContent = 'Show Details \u25bc';
        }
    }

    function onAnswer(fieldKey, value) {
        // Update char count
        var cc = document.getElementById('cc-' + fieldKey);
        if (cc) cc.textContent = value.length > 0 ? value.length + ' chars' : '';
        saveResponse(fieldKey, value);
    }

    async function playAudio(sectionId) {
        var audio = document.getElementById('audio-' + sectionId);
        var btn = document.getElementById('play-btn-' + sectionId);
        var status = document.getElementById('audio-status-' + sectionId);
        if (!audio || !btn) return;

        if (currentlyPlaying === sectionId && !audio.paused) { audio.pause(); btn.textContent = '\u25b6 Resume'; return; }
        if (currentlyPlaying === sectionId && audio.paused && audio.src) { audio.play(); btn.textContent = '\u23f8 Pause'; return; }

        if (currentlyPlaying && currentlyPlaying !== sectionId) {
            var old = document.getElementById('audio-' + currentlyPlaying);
            var oldBtn = document.getElementById('play-btn-' + currentlyPlaying);
            if (old) { old.pause(); old.currentTime = 0; }
            if (oldBtn) oldBtn.textContent = '\u25b6 Play Chapter';
        }

        btn.textContent = '\u23f3 Loading...';
        if (status) status.textContent = 'Finding audio...';

        try {
            var url = await resolveAudioUrl(sectionId);
            if (!url) { btn.textContent = '\u274c No Audio'; if (status) status.textContent = 'Try Spotify above.'; return; }

            audio.src = url;
            currentlyPlaying = sectionId;

            audio.oncanplay = function () { audio.play(); btn.textContent = '\u23f8 Pause'; if (status) status.textContent = 'Playing...'; };
            audio.ontimeupdate = function () { if (status && audio.duration) status.textContent = fmtTime(audio.currentTime) + ' / ' + fmtTime(audio.duration); };
            audio.onended = function () { btn.textContent = '\u25b6 Replay'; if (status) status.textContent = 'Finished'; currentlyPlaying = null; };
            audio.onerror = function () { btn.textContent = '\u274c Error'; if (status) status.textContent = 'Could not play. Try Spotify.'; currentlyPlaying = null; };
            audio.load();
        } catch (e) {
            btn.textContent = '\u274c Error';
            if (status) status.textContent = e.message;
        }
    }

    async function markDone(sectionId) {
        var done = sectionsCompleted.indexOf(sectionId) !== -1;
        if (!done) {
            sectionsCompleted.push(sectionId);
            toast('\u2705 ' + sectionId + ' completed! (' + sectionsCompleted.length + '/' + TOTAL_SECTIONS + ')', 'success');
        } else {
            sectionsCompleted = sectionsCompleted.filter(function (s) { return s !== sectionId; });
            toast('Section unmarked', 'info');
        }
        updateProgressUI();
        renderSections();
        saveProgress();
        if (sectionsCompleted.length === TOTAL_SECTIONS) celebrateCompletion();
    }

    /* ── UI ────────────────────────────────────────────────────── */
    function updateProgressUI() {
        var pct = Math.round((sectionsCompleted.length / TOTAL_SECTIONS) * 100);
        var bar = document.getElementById('progressBar');
        var pctEl = document.getElementById('progressPercentage');
        var txt = document.getElementById('progressText');
        var unlock = document.getElementById('unlockProgress');
        if (bar) bar.style.width = pct + '%';
        if (pctEl) pctEl.textContent = pct + '%';
        if (txt) txt.textContent = sectionsCompleted.length + ' of ' + TOTAL_SECTIONS + ' sections completed';
        if (unlock) unlock.textContent = sectionsCompleted.length + '/' + TOTAL_SECTIONS + ' sections complete';
    }

    function celebrateCompletion() {
        if (typeof confetti === 'function') {
            setTimeout(function () { confetti({ particleCount: 60, angle: 60, spread: 55, origin: { x: 0 } }); }, 300);
            setTimeout(function () { confetti({ particleCount: 60, angle: 120, spread: 55, origin: { x: 1 } }); }, 500);
        }
        toast('\ud83c\udf89 Phase 1 COMPLETE! You have unlocked Phase 2: Understanding!', 'success');
    }

    function toast(message, type) {
        var el = document.createElement('div');
        el.className = 'toast ' + (type || 'info');
        el.textContent = message;
        document.body.appendChild(el);
        requestAnimationFrame(function () { el.classList.add('show'); });
        setTimeout(function () { el.classList.remove('show'); setTimeout(function () { el.remove(); }, 400); }, 3500);
    }

    function fmtTime(sec) { var m = Math.floor(sec / 60), s = Math.floor(sec % 60); return m + ':' + (s < 10 ? '0' : '') + s; }
    function escAttr(str) { return str.replace(/'/g, "\\'").replace(/"/g, '&quot;'); }

    /* ── PUBLIC API ───────────────────────────────────────────── */
    window.__p1 = {
        toggle: toggle,
        playAudio: playAudio,
        markDone: markDone,
        openJournal: function (t) { window.location.href = 'members-new.html#journal?prompt=' + encodeURIComponent(t); },
        onAnswer: onAnswer
    };

})();
